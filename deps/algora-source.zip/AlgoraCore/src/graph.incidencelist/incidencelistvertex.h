/**
 * Copyright (C) 2013 - 2019 : Kathrin Hanauer
 *
 * This file is part of Algora.
 *
 * Algora is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Algora is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Algora.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Contact information:
 *   http://algora.xaikal.org
 */

#ifndef INCIDENCELISTVERTEX_H
#define INCIDENCELISTVERTEX_H

#include "graph/vertex.h"
#include "graph/arc.h"
#include "graph/graph_functional.h"
#include "property/fastpropertymap.h"

#include <vector>
#include <memory>

namespace Algora {

class IncidenceListGraph;
class Arc;
class MultiArc;
class ArcVisitor;

class IncidenceListVertex : public Vertex
{
    friend class IncidenceListGraph;
    friend class IncidenceListGraphImplementation;
    friend class SuperDiGraph;

public:
    class ArcListView;

    explicit IncidenceListVertex(id_type id,
                                 FastPropertyMap<size_type> &sharedOutIndex,
                                 FastPropertyMap<size_type> &sharedInIndex,
                                 GraphArtifact *parent = nullptr, size_type index = 0);
    virtual ~IncidenceListVertex();

    // disable copying and moving
    IncidenceListVertex(const IncidenceListVertex &other) = delete;
    IncidenceListVertex &operator=(const IncidenceListVertex &other) = delete;
    IncidenceListVertex(IncidenceListVertex &&other) = delete;
    IncidenceListVertex &operator=(IncidenceListVertex &&other) = delete;

    bool hasOutgoingArc(const Arc *a) const;
    bool hasIncomingArc(const Arc *a) const;
    bool hasEdge(const Arc *a) const;
    Arc *outgoingArcAt(size_type i, bool multiArcsAsSimple = false) const;
    Arc *incomingArcAt(size_type i, bool multiArcsAsSimple = false) const;
    Arc *undirectedEdgeAt(size_type i) const;

    size_type outIndexOf(const Arc *a) const;
    size_type inIndexOf(const Arc *a) const;
    size_type undirectedIndexOf(const Arc *a) const;

    void acceptOutgoingArcVisitor(ArcVisitor *aVisitor) const;
    void acceptIncomingArcVisitor(ArcVisitor *aVisitor) const;
    bool mapOutgoingArcs(const ArcMapping &avFun, const ArcPredicate &breakCondition = arcFalse, bool checkValidity = true) const;
    bool mapIncomingArcs(const ArcMapping &avFun, const ArcPredicate &breakCondition = arcFalse, bool checkValidity = true) const;
    bool mapEdges(const ArcMapping &avFun, const ArcPredicate &breakCondition = arcFalse, bool checkValidity = true) const;

    size_type getOutDegree(bool multiArcsAsSimple = false) const;
    size_type getInDegree(bool multiArcsAsSimple = false) const;
    size_type getUndirectedDegree() const;
    bool isSource() const;
    bool isSink() const;
    bool isIsolated() const { return isSource() && isSink(); }

    size_type getIndex() const;

    bool mapDeactivatedOutgoingArcs(const ArcMapping &avFun, const ArcPredicate &breakCondition = arcFalse) const;
    bool mapDeactivatedIncomingArcs(const ArcMapping &avFun, const ArcPredicate &breakCondition = arcFalse) const;
    bool mapDeactivatedEdges(const ArcMapping &avFun, const ArcPredicate &breakCondition = arcFalse) const;

    ArcListView &getOutgoingArcs();
    ArcListView &getIncomingArcs();
    ArcListView &getEdges();

    void swapOutgoingArcs(size_type i, size_type j);
    void swapIncomingArcs(size_type i, size_type j);
    void swapEdges(size_type i, size_type j);
    void swapOutgoingArcs(Arc *iArc, Arc *jArc);
    void swapIncomingArcs(Arc *iArc, Arc *jArc);
    void swapEdges(Arc *iArc, Arc *jArc);

protected:
    [[deprecated("use addOutgoingSimpleArc() or addOutgoingMultiArc() instead")]]
    void addOutgoingArc(Arc *a);
    void addOutgoingMultiArc(MultiArc *ma);
    void addOutgoingSimpleArc(Arc *ma);
    bool removeOutgoingArc(const Arc *a);
    void clearOutgoingArcs();

    [[deprecated("use addIncomingSimpleArc() or addIncomingMultiArc() instead")]]
    void addIncomingArc(Arc *a);
    void addIncomingMultiArc(MultiArc *a);
    void addIncomingSimpleArc(Arc *a);
    bool removeIncomingArc(const Arc *a);
    void clearIncomingArcs();

    void addSimpleEdge(Arc *a);
    bool removeSimpleEdge(const Arc *a);
    void clearEdges();
    bool mapOwnEdges(const ArcMapping &avFun, const ArcPredicate &breakCondition = arcFalse, bool checkValidity = true) const;

    void enableConsistencyCheck(bool enable);

    void setIndex(size_type i);

    void hibernate();
    void recycle();

    // (de)activation of arcs
    bool activateOutgoingArc(Arc *a);
    bool activateIncomingArc(Arc *a);
    bool activateEdge(Arc *a);
    bool deactivateOutgoingArc(Arc *a);
    bool deactivateIncomingArc(Arc *a);
    bool deactivateEdge(Arc *a);

    void activateAllOutgoingArcs();
    void deactivateAllOutgoingArcs();
    void activateAllIncomingArcs();
    void deactivateAllIncomingArcs();

    void activateAllEdges();
    void deactivateAllEdges();

private:
    class CheshireCat;
    CheshireCat *grin;
};

class IncidenceListVertex::ArcListView
{
    using ArcList = std::vector<Arc*>;
    using const_iterator = ArcList::const_iterator;
    using reference = ArcList::reference;
    using const_reference = ArcList::const_reference;

    friend class IncidenceListVertex;

public:
    const_iterator begin() const { return indices->vector.begin(); }
    const_iterator end() const { return indices->vector.end(); }
    const_iterator cbegin() const { return indices->vector.cbegin(); }
    const_iterator cend() const { return indices->vector.cend(); }
    const_reference operator[]( size_type pos ) const { return indices->vector[pos]; }
    size_type size() const noexcept { return indices->vector.size(); }
    const_reference front() const { return indices->vector.front(); }
    const_reference back() const { return indices->vector.back(); }

    void swap(size_type i, size_type j) {
        indices->doSwap(i, j);
    }

    ~ArcListView() = default;

private:
    struct IndexBase {
        const IncidenceListVertex *vertex;
        ArcList &vector;

        IndexBase(const IncidenceListVertex *v, ArcList &al) : vertex(v), vector(al) {}
        virtual ~IndexBase() = default;
        virtual void doSwap(size_type i, size_type j) = 0;
        virtual std::unique_ptr<IndexBase> clone() const = 0;
    };
    struct OneIndex final : public IndexBase {
        FastPropertyMap<size_type> &index;

        OneIndex(const IncidenceListVertex *v, ArcList &al, FastPropertyMap<size_type> &idx)
            : IndexBase(v, al), index(idx) {}
        virtual void doSwap(size_type i, size_type j) override {
            using std::swap;
            assert(index[vector[i]] == i);
            assert(index[vector[j]] == j);
            swap(vector[i], vector[j]);
            index.setValue(vector[i], i);
            index.setValue(vector[j], j);
        }
        virtual std::unique_ptr<IndexBase> clone() const override {
            return std::make_unique<OneIndex>(*this);
        }
    };
    struct TwoIndices final : public IndexBase {
        FastPropertyMap<size_type> &index1;
        FastPropertyMap<size_type> &index2;

        TwoIndices(const IncidenceListVertex *v, ArcList &al, FastPropertyMap<size_type> &idx1, FastPropertyMap<size_type> &idx2)
            : IndexBase(v, al), index1(idx1), index2(idx2) {}
        virtual void doSwap(size_type i, size_type j) override {
            using std::swap;
            FastPropertyMap<size_type> &indexI
                = vector[i]->getFirst() == vertex ? index1 : index2;
            FastPropertyMap<size_type> &indexJ
                = vector[j]->getFirst() == vertex ? index1 : index2;
            assert(indexI[vector[i]] == i);
            assert(indexJ[vector[j]] == j);
            swap(vector[i], vector[j]);
            indexJ.setValue(vector[i], i);
            indexI.setValue(vector[j], j);
            if (!vector[i]->isDirected() && vector[i]->isLoop()) {
                assert(&indexI == &index1);
                index2.setValue(vector[i], i);
            }
            if (!vector[j]->isDirected() && vector[j]->isLoop()) {
                assert(&indexJ == &index1);
                index2.setValue(vector[j], j);
            }
        }
        virtual std::unique_ptr<IndexBase> clone() const override {
            return std::make_unique<TwoIndices>(*this);
        }
    };
    std::unique_ptr<IndexBase> indices;

    ArcListView(const IncidenceListVertex *v, ArcList &al, FastPropertyMap<size_type> &idx)
        : indices(std::make_unique<OneIndex>(OneIndex(v, al, idx))) {}
    ArcListView(const IncidenceListVertex *v, ArcList &al, FastPropertyMap<size_type> &idx1, FastPropertyMap<size_type> &idx2)
        : indices(std::make_unique<TwoIndices>(TwoIndices(v, al, idx1, idx2))) {}

    ArcListView(ArcListView &&) = default;
    ArcListView &operator=(ArcListView &&) = default;
    ArcListView(const ArcListView &other)
        : indices(other.indices->clone()) {}
    ArcListView &operator=(const ArcListView &other) {
        ArcListView tmp(other);
        std::swap(indices, tmp.indices);
        return *this;
    }
};


}

#endif // INCIDENCELISTVERTEX_H
