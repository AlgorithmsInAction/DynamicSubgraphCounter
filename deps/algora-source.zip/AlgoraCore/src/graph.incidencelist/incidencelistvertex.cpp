/**
 * Copyright (C) 2013 - 2019 : Kathrin Hanauer
 *
 * This file is part of Algora.
 *
 * Algora is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Algora is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Algora.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Contact information:
 *   http://algora.xaikal.org
 */

#include "incidencelistvertex.h"

#include "incidencelistgraph.h"
#include "graph/parallelarcsbundle.h"
#include "graph.visitor/arcvisitor.h"
#include "property/propertymap.h"

#include <vector>
#include <stdexcept>
#include <algorithm>
#include <cassert>
#include <climits>

//#define DEBUG_ILISTVERTEX

#ifdef DEBUG_ILISTVERTEX
#include <iostream>
#define PRINT_DEBUG(msg) std::cout << "IncidenceListVertex: " << msg << std::endl;
#define IF_DEBUG(cmd) cmd;
#else
#define PRINT_DEBUG(msg)
#define IF_DEBUG(cmd)
#endif

namespace Algora {

typedef typename std::vector<Arc*> ArcList;
typedef typename std::vector<MultiArc*> MultiArcList;

template <typename AL, typename PM>
bool removeArcFromList(AL &list, PM &indexMap, const Arc *arc);
template <typename AL, typename PM>
bool removeEdgeFromList(AL &list, PM &outIndexMap, PM &inIndexMap, const Arc *arc, const Vertex *v);
bool removeBundledArcFromList(PropertyMap<ParallelArcsBundle*> &bundleMap, const Arc *arc);
template <typename AL, typename PM>
bool isArcInList(const PM &indexMap, AL &list, const Arc *arc);
template <typename AL, typename PM>
bool isBundledArc(const PropertyMap<ParallelArcsBundle*> &bundleMap, AL &list,
                  const PM &indexMap, const Arc *arc);

class IncidenceListVertex::CheshireCat {
public:
    IncidenceListVertex *vertex;
    size_type index;
    bool checkConsisteny;

    ArcList outgoingArcs;
    ArcList incomingArcs;
    ArcList undirectedEdges;
    MultiArcList outgoingMultiArcs;
    MultiArcList incomingMultiArcs;

    ArcList deactivatedOutgoingArcs;
    ArcList deactivatedIncomingArcs;
    ArcList deactivatedEdges;
    MultiArcList deactivatedOutgoingMultiArcs;
    MultiArcList deactivatedIncomingMultiArcs;

    PropertyMap<ParallelArcsBundle*> bundle;

    FastPropertyMap<size_type> &outIndex;
    FastPropertyMap<size_type> &inIndex;
    PropertyMap<size_type> multiOutIndex;
    PropertyMap<size_type> multiInIndex;

    ArcListView outArcsView;
    ArcListView inArcsView;
    ArcListView edgesView;

    CheshireCat(
            IncidenceListVertex *v,
            FastPropertyMap<size_type> &outIndex,
            FastPropertyMap<size_type> &inIndex,
            size_type i)
        : vertex(v), index(i),
        outIndex(outIndex), inIndex(inIndex),
        outArcsView(vertex, outgoingArcs, outIndex),
        inArcsView(vertex, incomingArcs, inIndex),
        edgesView(vertex, undirectedEdges, outIndex, inIndex)
    {
        multiOutIndex.setDefaultValue(outIndex.getDefaultValue());
        multiInIndex.setDefaultValue(inIndex.getDefaultValue());
        bundle.setDefaultValue(nullptr);
    }

    void clear() {
        for (Arc *a : outgoingArcs) {
            outIndex.resetToDefault(a);
        }
        for (Arc *a : incomingArcs) {
            outIndex.resetToDefault(a);
        }
        for (size_type i = 0; i < undirectedEdges.size(); i++) {
            auto &a = undirectedEdges[i];
            if (outIndex[a] == i) {
                outIndex.resetToDefault(a);
            } else {
                inIndex.resetToDefault(a);
            }
        }

        outgoingArcs.clear();
        incomingArcs.clear();
        undirectedEdges.clear();
        outgoingMultiArcs.clear();
        incomingMultiArcs.clear();
        deactivatedOutgoingArcs.clear();
        deactivatedIncomingArcs.clear();
        deactivatedEdges.clear();
        deactivatedOutgoingMultiArcs.clear();
        deactivatedIncomingMultiArcs.clear();

        multiOutIndex.resetAll();
        multiInIndex.resetAll();
        bundle.resetAll();
    }

    void clearOutgoingArcs() {
        for (Arc *a : outgoingArcs) {
            outIndex.resetToDefault(a);
        }
        for (Arc *a : outgoingMultiArcs) {
            multiOutIndex.resetToDefault(a);
        }
        for (Arc *a : deactivatedOutgoingArcs) {
            outIndex.resetToDefault(a);
        }
        for (Arc *a : deactivatedOutgoingMultiArcs) {
            multiOutIndex.resetToDefault(a);
        }
        outgoingArcs.clear();
        outgoingMultiArcs.clear();
        deactivatedOutgoingArcs.clear();
        deactivatedOutgoingMultiArcs.clear();
    }

    void clearIncomingArcs() {
        for (Arc *a : incomingArcs) {
            inIndex.resetToDefault(a);
        }
        for (Arc *a : incomingMultiArcs) {
            multiInIndex.resetToDefault(a);
        }
        for (Arc *a : deactivatedIncomingArcs) {
            inIndex.resetToDefault(a);
        }
        for (Arc *a : deactivatedIncomingMultiArcs) {
            multiInIndex.resetToDefault(a);
        }
        incomingArcs.clear();
        incomingMultiArcs.clear();
        deactivatedIncomingArcs.clear();
        deactivatedIncomingMultiArcs.clear();
    }

    void clearEdges() {
        for (size_type i = 0; i < undirectedEdges.size(); i++) {
            auto &a = undirectedEdges[i];
            if (outIndex[a] == i) {
                outIndex.resetToDefault(a);
            } else {
                inIndex.resetToDefault(a);
            }
        }

        for (size_type i = 0; i < deactivatedEdges.size(); i++) {
            auto &a = deactivatedEdges[i];
            if (outIndex[a] == i) {
                outIndex.resetToDefault(a);
            } else {
                inIndex.resetToDefault(a);
            }
        }

        undirectedEdges.clear();
        deactivatedEdges.clear();
    }

    void deactivateAllOutgoingArcs() {
        auto i = deactivatedOutgoingArcs.size();
        for (auto *a : outgoingArcs) {
            deactivatedOutgoingArcs.push_back(a);
            outIndex.setValue(a, i);
            i++;
        }
        i = deactivatedOutgoingMultiArcs.size();
        for (auto *a : outgoingMultiArcs) {
            deactivatedOutgoingMultiArcs.push_back(a);
            multiOutIndex.setValue(a, i);
            i++;
        }
        outgoingArcs.clear();
        outgoingMultiArcs.clear();
    }

    void deactivateAllIncomingArcs() {
        auto i = deactivatedIncomingArcs.size();
        for (auto *a : incomingArcs) {
            deactivatedIncomingArcs.push_back(a);
            inIndex.setValue(a, i);
            i++;
        }
        i = deactivatedIncomingMultiArcs.size();
        for (auto *a : incomingMultiArcs) {
            deactivatedIncomingMultiArcs.push_back(a);
            multiInIndex.setValue(a, i);
            i++;
        }
        incomingArcs.clear();
        incomingMultiArcs.clear();
    }

    void deactivateAllEdges() {
        auto i = deactivatedEdges.size();
        for (size_type j = 0; j < undirectedEdges.size(); j++) {
            auto &a = undirectedEdges[j];
            deactivatedEdges.push_back(a);
            if (outIndex[a] == j) {
                outIndex.setValue(a, i);
            } else {
                inIndex.setValue(a, i);
            }
            i++;
        }
        undirectedEdges.clear();
    }
};


IncidenceListVertex::IncidenceListVertex(id_type id, FastPropertyMap<size_type> &sharedOutIndex,
                                         FastPropertyMap<size_type> &sharedInIndex,
                                         GraphArtifact *parent, size_type index)
    : Vertex(id, parent), grin(new CheshireCat(this, sharedOutIndex, sharedInIndex, index))
{
    grin->checkConsisteny = true;
}

IncidenceListVertex::~IncidenceListVertex()
{
    delete grin;
}

IncidenceListVertex::size_type IncidenceListVertex::getOutDegree(bool multiArcsAsSimple) const
{
    auto deg = grin->outgoingArcs.size();
    if (multiArcsAsSimple) {
        return deg + grin->outgoingMultiArcs.size();
    }
    for (MultiArc *ma : grin->outgoingMultiArcs) {
        deg += ma->getSize();
    }
    return deg;
}

[[deprecated("use addOutgoingSimpleArc() or addOutgoingMultiArc() instead")]]
void IncidenceListVertex::addOutgoingArc(Arc *a)
{
    MultiArc *ma = dynamic_cast<MultiArc*>(a);
    if (ma) {
        addOutgoingMultiArc(ma);
    } else {
        addOutgoingSimpleArc(a);
    }
}

void IncidenceListVertex::addOutgoingMultiArc(MultiArc *ma)
{
    if (grin->checkConsisteny && ma->getTail() != this) {
        throw std::invalid_argument("Arc has other tail.");
    }

    grin->multiOutIndex.setValue(ma, grin->outgoingMultiArcs.size());
    grin->outgoingMultiArcs.push_back(ma);
    ParallelArcsBundle *pab = dynamic_cast<ParallelArcsBundle*>(ma);
    if (pab) {
        pab->mapArcs([&](Arc *a) {
            grin->bundle.setValue(a, pab);
        });
    }
}

void IncidenceListVertex::addOutgoingSimpleArc(Arc *a)
{
    assert(!dynamic_cast<MultiArc*>(a));

    if (grin->checkConsisteny && a->getTail() != this) {
        throw std::invalid_argument("Arc has other tail.");
    }

    grin->outIndex.setValue(a, grin->outgoingArcs.size());
    grin->outgoingArcs.push_back(a);
}

bool IncidenceListVertex::removeOutgoingArc(const Arc *a)
{
    if (grin->checkConsisteny && a->getTail() != this) {
        throw std::invalid_argument("Arc has other tail.");
    }
    return removeArcFromList(grin->outgoingArcs, grin->outIndex, a)
            || removeArcFromList(grin->outgoingMultiArcs, grin->multiOutIndex, a)
            || removeBundledArcFromList(grin->bundle, a);
}

void IncidenceListVertex::clearOutgoingArcs()
{
    grin->clearOutgoingArcs();
}

IncidenceListVertex::size_type IncidenceListVertex::getInDegree(bool multiArcsAsSimple) const
{
    auto deg = grin->incomingArcs.size();
    if (multiArcsAsSimple) {
        return deg + grin->incomingMultiArcs.size();
    }
    for (MultiArc *ma : grin->incomingMultiArcs) {
        deg += ma->getSize();
    }
    return deg;
}

bool IncidenceListVertex::isSource() const
{
    return grin->incomingArcs.empty() && grin->incomingMultiArcs.empty();
}

bool IncidenceListVertex::isSink() const
{
    return grin->outgoingArcs.empty() && grin->outgoingMultiArcs.empty();
}

[[deprecated("use addIncomingSimpleArc() or addIncomingMultiArc() instead")]]
void IncidenceListVertex::addIncomingArc(Arc *a)
{
    MultiArc *ma = dynamic_cast<MultiArc*>(a);
    if (ma) {
        addIncomingMultiArc(ma);
    } else {
        addIncomingSimpleArc(a);
    }
}

void IncidenceListVertex::addIncomingMultiArc(MultiArc *ma)
{
    if (grin->checkConsisteny && ma->getHead() != this) {
        throw std::invalid_argument("Arc has other head.");
    }

    grin->multiInIndex.setValue(ma, grin->incomingMultiArcs.size());
    grin->incomingMultiArcs.push_back(ma);
    ParallelArcsBundle *pab = dynamic_cast<ParallelArcsBundle*>(ma);
    if (pab) {
        pab->mapArcs([&](Arc *a) {
            grin->bundle.setValue(a, pab);
        });
    }
}

void IncidenceListVertex::addIncomingSimpleArc(Arc *a)
{
    assert(!dynamic_cast<MultiArc*>(a));

    if (grin->checkConsisteny && a->getHead() != this) {
        throw std::invalid_argument("Arc has other head.");
    }

    grin->inIndex.setValue(a, grin->incomingArcs.size());
    grin->incomingArcs.push_back(a);
}

bool IncidenceListVertex::removeIncomingArc(const Arc *a)
{
    if (grin->checkConsisteny && a->getHead() != this) {
        throw std::invalid_argument("Arc has other head.");
    }
    return removeArcFromList(grin->incomingArcs, grin->inIndex, a)
            || removeArcFromList(grin->incomingMultiArcs, grin->multiInIndex, a)
            || removeBundledArcFromList(grin->bundle, a);
}

void IncidenceListVertex::clearIncomingArcs()
{
    grin->clearIncomingArcs();
}

IncidenceListVertex::size_type IncidenceListVertex::getUndirectedDegree() const
{
    return grin->undirectedEdges.size();
}

void IncidenceListVertex::addSimpleEdge(Arc *a)
{
    assert(!dynamic_cast<MultiArc*>(a));

    if (grin->checkConsisteny && a->getTail() != this && a->getHead() != this) {
        throw std::invalid_argument("No end vertex of undirected edge.");
    }

    if (a->getTail() == this) {
        grin->outIndex.setValue(a, grin->undirectedEdges.size());
    }
    if (a->getHead() == this) {
        grin->inIndex.setValue(a, grin->undirectedEdges.size());
    }
    grin->undirectedEdges.push_back(a);
}

bool IncidenceListVertex::removeSimpleEdge(const Arc *a)
{
    PRINT_DEBUG("Trying to remove " << a << " from " << this->getName());
    if (grin->checkConsisteny && a->getTail() != this && a->getHead() != this) {
        throw std::invalid_argument("No end vertex of undirected edge.");
    }

    return removeEdgeFromList(grin->undirectedEdges, grin->outIndex, grin->inIndex, a, this);
}

void IncidenceListVertex::clearEdges()
{
    grin->clearEdges();
}

bool IncidenceListVertex::mapOwnEdges(const ArcMapping &avFun,
                                      const ArcPredicate &breakCondition,
                                      bool checkValidity) const
{
    for (Arc *a : grin->undirectedEdges) {
        if (a->getTail() != this) {
            continue;
        }
        if (breakCondition(a)) {
            return false;
        }
        if (!checkValidity || a->isValid()) {
            avFun(a);
        }
    }
    return true;
}

void IncidenceListVertex::enableConsistencyCheck(bool enable)
{
    grin->checkConsisteny = enable;
}

IncidenceListVertex::size_type IncidenceListVertex::getIndex() const
{
    return grin->index;
}

bool IncidenceListVertex::activateOutgoingArc(Arc *a)
{
    if (removeArcFromList(grin->deactivatedOutgoingArcs, grin->outIndex, a)) {
        addOutgoingSimpleArc(a);
        return true;
    }
    if (removeArcFromList(grin->deactivatedOutgoingMultiArcs, grin->multiOutIndex, a)) {
        addOutgoingMultiArc(dynamic_cast<MultiArc*>(a));
        return true;
    }
    return false;
}

bool IncidenceListVertex::activateIncomingArc(Arc *a)
{
    if (removeArcFromList(grin->deactivatedIncomingArcs, grin->inIndex, a)) {
        addIncomingSimpleArc(a);
        return true;
    }
    if (removeArcFromList(grin->deactivatedIncomingMultiArcs, grin->multiInIndex, a)) {
        addIncomingMultiArc(dynamic_cast<MultiArc*>(a));
        return true;
    }
    return false;
}

bool IncidenceListVertex::activateEdge(Arc *a)
{
    if (removeEdgeFromList(grin->deactivatedEdges, grin->outIndex, grin->inIndex, a, this)) {
        addSimpleEdge(a);
        return true;
    }
    //bool isTail = a->getTail() == this;
    //if ((isTail && removeArcFromList(grin->deactivatedEdges, grin->outIndex, a))
    //        || (!isTail && removeArcFromList(grin->deactivatedEdges, grin->inIndex, a))) {
    //    addSimpleEdge(a);
    //    return true;
    //}

    return false;
}

bool IncidenceListVertex::deactivateOutgoingArc(Arc *a)
{
    if (!removeOutgoingArc(a)) {
        return false;
    }
    auto multiArc = dynamic_cast<MultiArc*>(a);
    if (multiArc) {
        grin->multiOutIndex.setValue(multiArc, grin->deactivatedOutgoingMultiArcs.size());
        grin->deactivatedOutgoingMultiArcs.push_back(multiArc);
    } else {
        grin->outIndex.setValue(a, grin->deactivatedOutgoingArcs.size());
        grin->deactivatedOutgoingArcs.push_back(a);
    }
    return true;
}

bool IncidenceListVertex::deactivateIncomingArc(Arc *a)
{
    if (!removeIncomingArc(a)) {
        return false;
    }
    auto multiArc = dynamic_cast<MultiArc*>(a);
    if (multiArc) {
        grin->multiInIndex.setValue(multiArc, grin->deactivatedIncomingArcs.size());
        grin->deactivatedIncomingMultiArcs.push_back(multiArc);
    } else {
        grin->inIndex.setValue(a, grin->deactivatedIncomingArcs.size());
        grin->deactivatedIncomingArcs.push_back(a);
    }
    return true;
}

bool IncidenceListVertex::deactivateEdge(Arc *a)
{
    if (!removeSimpleEdge(a)) {
        return false;
    }
    if (a->getTail() == this) {
        grin->outIndex.setValue(a, grin->deactivatedEdges.size());
    } 
    if (a->getHead() == this) {
        grin->inIndex.setValue(a, grin->deactivatedEdges.size());
    }
    grin->deactivatedEdges.push_back(a);
    return true;
}

void IncidenceListVertex::activateAllOutgoingArcs()
{
    for (auto *a : grin->deactivatedOutgoingArcs) {
        addOutgoingSimpleArc(a);
    }
    grin->deactivatedOutgoingArcs.clear();
    for (auto *a : grin->deactivatedOutgoingMultiArcs) {
        addOutgoingMultiArc(a);
    }
    grin->deactivatedOutgoingMultiArcs.clear();
}

void IncidenceListVertex::deactivateAllOutgoingArcs()
{
    grin->deactivateAllOutgoingArcs();
}

void IncidenceListVertex::activateAllIncomingArcs()
{
    for (auto *a : grin->deactivatedIncomingArcs) {
        addIncomingSimpleArc(a);
    }
    grin->deactivatedIncomingArcs.clear();
    for (auto *a : grin->deactivatedIncomingMultiArcs) {
        addIncomingMultiArc(a);
    }
    grin->deactivatedIncomingMultiArcs.clear();
}

void IncidenceListVertex::deactivateAllIncomingArcs()
{
    grin->deactivateAllIncomingArcs();
}

void IncidenceListVertex::activateAllEdges()
{
    for (auto *a : grin->deactivatedEdges) {
        addSimpleEdge(a);
    }
    grin->deactivatedEdges.clear();
}

void IncidenceListVertex::deactivateAllEdges()
{
    grin->deactivateAllEdges();
}

bool IncidenceListVertex::mapDeactivatedOutgoingArcs(const ArcMapping &avFun,
                                                     const ArcPredicate &breakCondition) const
{
    for (Arc *a : grin->deactivatedOutgoingArcs) {
        if (breakCondition(a)) {
            return false;
        }
        avFun(a);
    }
    for (Arc *a : grin->deactivatedOutgoingMultiArcs) {
        if (breakCondition(a)) {
            return false;
        }
        avFun(a);
    }
    return true;
}

bool IncidenceListVertex::mapDeactivatedIncomingArcs(const ArcMapping &avFun,
                                                     const ArcPredicate &breakCondition) const
{
    for (Arc *a : grin->deactivatedIncomingArcs) {
        if (breakCondition(a)) {
            return false;
        }
        avFun(a);
    }
    for (Arc *a : grin->deactivatedIncomingMultiArcs) {
        if (breakCondition(a)) {
            return false;
        }
        avFun(a);
    }
    return true;
}

bool IncidenceListVertex::mapDeactivatedEdges(const ArcMapping &avFun,
                                              const ArcPredicate &breakCondition) const
{
    for (Arc *e : grin->deactivatedEdges) {
        if (breakCondition(e)) {
            return false;
        }
        avFun(e);
    }
    return true;
}

void IncidenceListVertex::setIndex(size_type i)
{
    grin->index = i;
}

void IncidenceListVertex::hibernate()
{
    invalidate();
    reset(); // reset name
    grin->clear();
}

void IncidenceListVertex::recycle()
{
    revalidate();
}

bool IncidenceListVertex::hasOutgoingArc(const Arc *a) const
{
    return isArcInList(grin->outIndex, grin->outgoingArcs, a)
            || isArcInList(grin->multiOutIndex, grin->outgoingMultiArcs, a)
            || isBundledArc(grin->bundle, grin->outgoingMultiArcs, grin->outIndex, a);
}

bool IncidenceListVertex::hasIncomingArc(const Arc *a) const
{
    return isArcInList(grin->inIndex, grin->incomingArcs, a)
            || isArcInList(grin->multiInIndex, grin->incomingMultiArcs, a)
            || isBundledArc(grin->bundle, grin->incomingMultiArcs, grin->inIndex, a);
}

bool IncidenceListVertex::hasEdge(const Arc *a) const
{
    return isArcInList(grin->outIndex, grin->undirectedEdges, a)
        || isArcInList(grin->inIndex, grin->undirectedEdges, a);
}

Arc *IncidenceListVertex::outgoingArcAt(size_type i, bool multiArcsAsSimple) const
{
    if (i < grin->outgoingArcs.size()) {
        return grin->outgoingArcs.at(i);
    }
    i -= grin->outgoingArcs.size();
    if (multiArcsAsSimple) {
        if (i < grin->outgoingMultiArcs.size()) {
            return grin->outgoingMultiArcs.at(i);
        }
    } else {
        for(MultiArc *a : grin->outgoingMultiArcs) {
            if (i < a->getSize()) {
                return a;
            }
            i -= a->getSize();
        }
    }
    throw std::invalid_argument("Index must be less than outdegree.");
}

Arc *IncidenceListVertex::incomingArcAt(size_type i, bool multiArcsAsSimple) const
{
    if (i < grin->incomingArcs.size()) {
        return grin->incomingArcs.at(i);
    }
    i -= grin->incomingArcs.size();
    if (multiArcsAsSimple) {
        if (i < grin->incomingMultiArcs.size()) {
            return grin->incomingMultiArcs.at(i);
        }
    } else {
        for(MultiArc *a : grin->incomingMultiArcs) {
            if (i < a->getSize()) {
                return a;
            }
            i -= a->getSize();
        }
    }
    throw std::invalid_argument("Index must be less than indegree.");
}

Arc *IncidenceListVertex::undirectedEdgeAt(size_type i) const
{
    return grin->undirectedEdges.at(i);
}

IncidenceListVertex::size_type IncidenceListVertex::outIndexOf(const Arc *a) const
{
    auto i = grin->outIndex(a);
    if (i != grin->outIndex.getDefaultValue()) {
        return i;
    }
    return grin->multiOutIndex(a);
}

IncidenceListVertex::size_type IncidenceListVertex::inIndexOf(const Arc *a) const
{
    auto i = grin->inIndex(a);
    if (i != grin->inIndex.getDefaultValue()) {
        return i;
    }
    return grin->multiInIndex(a);
}

IncidenceListVertex::size_type IncidenceListVertex::undirectedIndexOf(const Arc *a) const
{
    bool isTail = a->getTail() == this;
    return isTail ? grin->outIndex(a) : grin->inIndex(a);
}

void IncidenceListVertex::acceptOutgoingArcVisitor(ArcVisitor *aVisitor) const
{
    mapOutgoingArcs(aVisitor->getVisitorFunction(), arcFalse);
}

void IncidenceListVertex::acceptIncomingArcVisitor(ArcVisitor *aVisitor) const
{
    mapIncomingArcs(aVisitor->getVisitorFunction(), arcFalse);
}

bool IncidenceListVertex::mapOutgoingArcs(const ArcMapping &avFun,
                                          const ArcPredicate &breakCondition,
                                          bool checkValidity) const
{
    for (Arc *a : grin->outgoingArcs) {
        if (breakCondition(a)) {
            return false;
        }
        if (!checkValidity || a->isValid()) {
            avFun(a);
        }
    }
    for (Arc *a : grin->outgoingMultiArcs) {
        if (breakCondition(a)) {
            return false;
        }
        if (!checkValidity || a->isValid()) {
            avFun(a);
        }
    }
    return true;
}

bool IncidenceListVertex::mapIncomingArcs(const ArcMapping &avFun,
                                          const ArcPredicate &breakCondition,
                                          bool checkValidity) const
{
    for (Arc *a : grin->incomingArcs) {
        if (breakCondition(a)) {
            return false;
        }
        if (!checkValidity || a->isValid()) {
            avFun(a);
        }
    }
    for (Arc *a : grin->incomingMultiArcs) {
        if (breakCondition(a)) {
            return false;
        }
        if (!checkValidity || a->isValid()) {
            avFun(a);
        }
    }
    return true;
}

bool IncidenceListVertex::mapEdges(const ArcMapping &avFun,
                                          const ArcPredicate &breakCondition,
                                          bool checkValidity) const
{
    for (Arc *a : grin->undirectedEdges) {
        if (breakCondition(a)) {
            return false;
        }
        if (!checkValidity || a->isValid()) {
            avFun(a);
        }
    }
    return true;
}

IncidenceListVertex::ArcListView &IncidenceListVertex::getOutgoingArcs() {
    return grin->outArcsView;
}

IncidenceListVertex::ArcListView &IncidenceListVertex::getIncomingArcs() {
    return grin->inArcsView;
}

IncidenceListVertex::ArcListView &IncidenceListVertex::getEdges() {
    return grin->edgesView;
}

void IncidenceListVertex::swapOutgoingArcs(size_type i, size_type j) {
    grin->outArcsView.swap(i, j);
}

void IncidenceListVertex::swapIncomingArcs(size_type i, size_type j) {
    grin->inArcsView.swap(i, j);
}

void IncidenceListVertex::swapEdges(size_type i, size_type j) {
    grin->edgesView.swap(i, j);
}

void IncidenceListVertex::swapOutgoingArcs(Arc *iArc, Arc *jArc) {
    auto i = grin->outIndex(iArc);
    auto j = grin->outIndex(jArc);
    assert(grin->outgoingArcs[i] == iArc);
    assert(grin->outgoingArcs[j] == jArc);
    grin->outArcsView.swap(i, j);
}

void IncidenceListVertex::swapIncomingArcs(Arc *iArc, Arc *jArc) {
    auto i = grin->inIndex(iArc);
    auto j = grin->inIndex(jArc);
    assert(grin->incomingArcs[i] == iArc);
    assert(grin->incomingArcs[j] == jArc);
    grin->inArcsView.swap(i, j);
}

void IncidenceListVertex::swapEdges(Arc *iArc, Arc *jArc) {
    auto i = iArc->getTail() == this ? grin->outIndex(iArc) : grin->inIndex(iArc);
    auto j = jArc->getTail() == this ? grin->outIndex(jArc) : grin->inIndex(jArc);
    assert(grin->undirectedEdges[i] == iArc);
    assert(grin->undirectedEdges[j] == jArc);
    grin->edgesView.swap(i, j);
}

template <typename AL, typename PM>
bool removeArcFromList(AL &list, PM &indexMap, const Arc *arc) {
    auto i = indexMap(arc);
    if (i >= list.size() || list[i] != arc) {
        return false;
    }
    assert(list[i] == arc);
    auto swap = list.back();
    list[i] = swap;
    indexMap.setValue(swap, i);
    indexMap.resetToDefault(arc);
    list.pop_back();
    return true;
}

template <typename AL, typename PM>
bool removeEdgeFromList(AL &list, PM &outIndexMap, PM &inIndexMap, const Arc *arc, const Vertex *v) {
    PRINT_DEBUG("Trying to remove edge " << arc << " from incidence list of " << v);
    auto i = arc->getTail() == v ? outIndexMap(arc) : inIndexMap(arc);
    if (i >= list.size() || list[i] != arc) {
        return false;
    }
    assert(list[i] == arc);
    auto swap = list.back();
    list[i] = swap;
    // note: if edge is loop, v is both tail and head!
    if (swap->getTail() == v) {
        outIndexMap.setValue(swap, i);
    }
    if (swap->getHead() == v) {
        inIndexMap.setValue(swap, i);
    }
    if (arc->getTail() == v) {
        outIndexMap.resetToDefault(arc);
    }
    if (arc->getHead() == v) {
        inIndexMap.resetToDefault(arc);
    }
    list.pop_back();
    return true;
}


bool removeBundledArcFromList(PropertyMap<ParallelArcsBundle*> &bundleMap, const Arc *arc) {
    ParallelArcsBundle *pmb = bundleMap(arc);
    if (!pmb) {
        return false;
    }
    assert(pmb->containsArc(arc));
    pmb->removeArc(arc);
    bundleMap.resetToDefault(arc);
    return true;
}

template <typename AL, typename PM>
bool isArcInList(const PM &indexMap, AL &list, const Arc *arc) {
    auto i = indexMap(arc);
    return i < list.size() && list[i] == arc;
}

template <typename AL, typename PM>
bool isBundledArc(const PropertyMap<ParallelArcsBundle*> &bundleMap, AL &list,
                  const PM &indexMap, const Arc *arc) {
    ParallelArcsBundle *pmb = bundleMap(arc);
    if (!pmb) {
        return false;
    }
    assert(pmb->containsArc(arc));
    return isArcInList(indexMap, list, pmb);
}

}
