/**
 * Copyright (C) 2013 - 2019 : Kathrin Hanauer
 *
 * This file is part of Algora.
 *
 * Algora is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Algora is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Algora.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Contact information:
 *   http://algora.xaikal.org
 */

#ifndef VERTEXPAIR_H
#define VERTEXPAIR_H

#include "graphartifact.h"
#include "vertex.h"
#include <cassert>

namespace Algora {

class VertexPair : public GraphArtifact
{
public:
    explicit VertexPair(Vertex *first, Vertex *second, GraphArtifact *parent = nullptr)
        : GraphArtifact(parent), first(first), second(second), ordered(true) {}

    explicit VertexPair(Vertex *first, Vertex *second, id_type id, GraphArtifact *parent = nullptr)
        : GraphArtifact(id, parent), first(first), second(second), ordered(true) {}

    explicit VertexPair(id_type id, GraphArtifact *parent = nullptr)
        : GraphArtifact(id, parent), first(nullptr), second(nullptr), ordered(true) { invalidate(); }

    virtual ~VertexPair() override { }

    Vertex *getFirst() const { return first; }
    Vertex *getSecond() const { return second; }
    bool isOrdered() const { return ordered; }

    Vertex *getOther(const Vertex *v) const {
        assert(v == first || v == second);
        return v == first ? second : first;
    }

    VertexPair &operator=(const VertexPair &other);
    VertexPair &operator=(VertexPair &&other);

    // GraphArtifact interface
public:
    virtual std::string typeString() const noexcept override {
        return "VertexPair";
    }
    virtual std::string toString() const override;

    // copying
    VertexPair(const VertexPair &other);

    // moving
    VertexPair(VertexPair &&other);

    void setFirst(Vertex *v) {
        first = v;
        checkOrder();
    }

    void setSecond(Vertex *v) {
        second = v;
        checkOrder();
    }

    void setOrdered(bool order) {
        ordered = order;
        checkOrder();
    }

    void set(Vertex *fst, Vertex *snd) {
        set(fst, snd, ordered);
    }

    void set(Vertex *fst, Vertex *snd, bool ord) {
        first = fst;
        second = snd;
        ordered = ord;
        checkOrder();
    }

private:
    Vertex *first;
    Vertex *second;
    bool ordered { true };

    void checkOrder() {
        if (!first || !second) {
            return;
        }
        if (!ordered && first->getId() > second->getId()) {
            std::swap(first, second);
        }
    }
};

inline bool operator==(const VertexPair &lhs, const VertexPair &rhs){
    return (lhs.isOrdered() == rhs.isOrdered())
        && (lhs.getFirst() == rhs.getFirst())
        && (lhs.getSecond() == rhs.getSecond());
}
inline bool operator< (const VertexPair &lhs, const VertexPair &rhs){
    return lhs.getFirst() < rhs.getFirst()
            || (lhs.getFirst() == rhs.getFirst() && lhs.getSecond() < rhs.getSecond())
            // deliberately sort ordered before unordered
            || (lhs.getFirst() == rhs.getFirst() && lhs.getSecond() == rhs.getSecond() && lhs.isOrdered() && !rhs.isOrdered());
}
inline bool operator!=(const VertexPair &lhs, const VertexPair &rhs){ return !operator==(lhs,rhs);}
inline bool operator> (const VertexPair &lhs, const VertexPair &rhs){ return  operator< (rhs,lhs);}
inline bool operator<=(const VertexPair &lhs, const VertexPair &rhs){ return !operator> (lhs,rhs);}
inline bool operator>=(const VertexPair &lhs, const VertexPair &rhs){ return !operator< (lhs,rhs);}

std::ostream &operator<<(std::ostream &out, const VertexPair *vp);

}

#endif // VERTEXPAIR_H
