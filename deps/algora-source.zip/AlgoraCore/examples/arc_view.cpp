/**
 * Copyright (C) 2022 : Kathrin Hanauer
 *
 * This file is part of Algora.
 *
 * Algora is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Algora is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Algora.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Contact information:
 *   http://algora.xaikal.org
 */

#include "graph.incidencelist/incidencelistgraph.h"

#include <iostream>
#include <algorithm>

int main(int argc, char *argv[])
{
	using namespace Algora;

	// First, we create a graph.
	// Calling setName() is optional, we only use it here to get a nicer output.
	IncidenceListGraph g;

	auto u = g.addVertex();
	u->setName("u");
	auto v = g.addVertex();
	v->setName("v");
	auto w = g.addVertex();
	w->setName("w");
	auto x = g.addVertex();
	x->setName("x");
	auto y = g.addVertex();
	y->setName("y");
	auto z = g.addVertex();
	z->setName("z");

	g.addArc(u, v)->setName("u -> v");
	g.addArc(u, y)->setName("u -> y");
	g.addArc(v, w)->setName("v -> w");
	g.addArc(v, x)->setName("v -> x [1]");
	g.addArc(v, x)->setName("v -> x [2]");
	g.addArc(x, u)->setName("x -> u");
	g.addArc(y, z)->setName("y -> z");
	g.addArc(z, w)->setName("z -> w");

    auto &v_out = v->getOutgoingArcs();
    std::cout << "All " << v_out.size() << " outgoing arcs of v: ";
    for (const auto &outArc : v_out) {
        std:: cout << outArc->getName() << ", ";
    }
    std::cout << std::endl;

    std::cout << "\nAdding arc v-> z...\n";
	g.addArc(v, z)->setName("v -> z");
    std::cout << "\nFirst outgoing arc of v: " << v_out.front()->getName() << std::endl;
    std::cout << "Last outgoing arc of v: " << v_out.back()->getName() << std::endl;

    // Does not work (and should not work):
    // std::swap(v_out[0], v_out[1]);
    // *v_out[0] = *v_out[1];

    std::cout << "\nReversing order of outgoing arcs of v...\n";
    for (auto i = 0U; i < v_out.size()/2; i++) {
        v_out.swap(i, v_out.size() - i - 1);
    }

    std::cout << "All " << v_out.size() << " outgoing arcs of v: ";
    for (const auto &outArc : v_out) {
        std:: cout << outArc->getName() << "; ";
    }
    std::cout << std::endl;

    std::cout << "\nRemoving second arc " << v_out[1]->getName() << " ...\n";
    g.removeArc(v_out[1]);

    std::cout << "\nAll " << v_out.size() << " outgoing arcs of v: ";
    for (const auto &outArc : v_out) {
        std:: cout << outArc->getName() << ", ";
    }
    std::cout << std::endl;

    auto &z_in = z->getIncomingArcs();
    std::cout << "\nAll " << z_in.size() << " incoming arcs of z: ";
    for (const auto &inArc : z_in) {
        std:: cout << inArc->getName() <<  "; ";
    }
    std::cout << std::endl;

    std::cout << "\nRemoving first arc " << z_in.front()->getName() << " ...\n";
    g.removeArc(z_in.front());
    std::cout << "\nAdding arc (u, z) ...\n";
	g.addArc(u, z)->setName("u -> z");

    std::cout << "\nAll " << z_in.size() << " incoming arcs of z: ";
    for (const auto &inArc : z_in) {
        std:: cout << inArc->getName() <<  "; ";
    }
    std::cout << std::endl;

	return 0;
}
