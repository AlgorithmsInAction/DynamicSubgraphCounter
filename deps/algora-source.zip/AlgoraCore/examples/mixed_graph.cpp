/**
 * Copyright (C) 2022 : Kathrin Hanauer
 *
 * This file is part of Algora.
 *
 * Algora is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Algora is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Algora.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Contact information:
 *   http://algora.xaikal.org
 */

#include "graph.incidencelist/incidencelistgraph.h"

#include <iostream>
#include <algorithm>

int main(int argc, char *argv[])
{
    using namespace Algora;

    IncidenceListGraph g;

    auto u = g.addVertex();
    u->setName("u");
    auto v = g.addVertex();
    v->setName("v");
    auto w = g.addVertex();
    w->setName("w");
    auto x = g.addVertex();
    x->setName("x");
    auto y = g.addVertex();
    y->setName("y");
    auto z = g.addVertex();
    z->setName("z");

    g.addArc(u, v)->setName("u -> v");
    auto uy = g.addEdge(u, y);
    uy->setName("{u, y}");
    g.addEdge(v, w)->setName("{v, w}");
    g.addEdge(v, x)->setName("{v, x}");
    g.addArc(v, x)->setName("v -> x");
    g.addEdge(x, v)->setName("{x, v}");
    g.addArc(y, z)->setName("y -> z");
    g.addArc(z, w)->setName("z -> w");
    auto vv = g.addEdge(v, v);
    vv->setName("{v}");

    auto &v_out = v->getOutgoingArcs();
    std::cout << "All " << v_out.size() << " outgoing arcs of v: ";
    for (const auto &outArc : v_out) {
        std:: cout << outArc->getName() << ", ";
    }
    std::cout << std::endl;

    auto &v_in = v->getIncomingArcs();
    std::cout << "\nAll " << v_in.size() << " incoming arcs of v: ";
    for (const auto &inArc : v_in) {
        std:: cout << inArc->getName() << ", ";
    }
    std::cout << std::endl;

    auto &v_un = v->getEdges();
    std::cout << "\nAll " << v_un.size() << " undirected incident edges of v: ";
    for (const auto &e: v_un) {
        std:: cout << e << ", ";
    }
    std::cout << std::endl;

    std::cout << "\nOutdegree of v: " << g.getOutDegree(v, true);
    std::cout << "\nIndegree of v: " << g.getInDegree(v, true);
    std::cout << "\nUndirected degree of v: " << g.getUndirectedDegree(v);

    std::cout << "\nReversing order of undirected edges of v...\n";
    for (auto i = 0U; i < v_un.size()/2; i++) {
        v_un.swap(i, v_un.size() - i - 1);
    }

    std::cout << "\nAll " << v_un.size() << " undirected incident edges of v: ";
    for (const auto &e: v_un) {
        std:: cout << e->getName() << ", ";
    }
    std::cout << std::endl;

    // -------
    std::cout << "\nLooking for loops incident to v...\n";

    auto vv2 = g.findArc(v, v);
    std::cout << "\nFind (v, v): " << (vv2 ? vv2->toString() : "<not found>");

    vv2 = g.findArc(v, v);
    std::cout << "\nFind (v, v): " << (vv2 ? vv2->toString() : "<not found>");

    vv2 = g.findEdge(v, v);
    std::cout << "\nFind {v, v}: " << (vv2 ? vv2->toString() : "<not found>");

    // -------

    std::cout << "\nRemoving loop {v}, adding arc (v, v).\n";

    g.removeEdge(vv);
    vv = g.addArc(v, v);
    vv->setName("v -> v");

    // -------
    std::cout << "\nLooking for loops incident to v...\n";

    vv2 = g.findArc(v, v);
    std::cout << "\nFind (v, v): " << (vv2 ? vv2->toString() : "<not found>");

    vv2 = g.findArc(v, v);
    std::cout << "\nFind (v, v): " << (vv2 ? vv2->toString() : "<not found>");

    vv2 = g.findEdge(v, v);
    std::cout << "\nFind {v, v}: " << (vv2 ? vv2->toString() : "<not found>");

    // -------

    std::cout << "\nTrying to remove loop (v, v) as undirected edge...";
    g.removeEdge(vv);
    std::cout << "\nTrying to remove loop (v, v) as directed arc...";
    g.removeArc(vv);
    std::cout << "\nAdding arc (w, v).\n";
    g.addArc(w, v)->setName("w -> v");

    // -------

    auto wv = g.findArc(w, v);
    std::cout << "\nFind (w, v): " << (wv ? wv->getName() : "<not found>");

    wv = g.findArc(v, w);
    std::cout << "\nFind (v, w): " << (wv ? wv->getName() : "<not found>");

    wv = g.findEdge(w, v);
    std::cout << "\nFind {w, v}: " << (wv ? wv->getName() : "<not found>");

    std::cout << "\nContains arc " << uy->getName() << " (correct: NO)? "  << (g.containsArc(uy) ? "yes" : "no");
    std::cout << "\nContains edge " << uy->getName() << " (correct: YES)? " << (g.containsEdge(uy) ? "yes" : "no");

    std::cout << std::endl;

    // -------

    std::cout << "\nEdges incident to " << x << ", via map:\n";
    g.mapIncidentEdges(x, [&](const auto &e) { std::cout << e->getName() << ", "; });
    std::cout << "\nEdges incident to " << x << ", via list view:\n";
    for (const auto &e : x->getEdges()) { std::cout << e->getName() << ", "; }
    std::cout << "\nAll edges:\n";
    g.mapEdges([&](const auto &e) { std::cout << e->getName() << ", "; });

    std::cout << std::endl;

    // -------

    std::cout << "\nDeactivating all edges incident to " << x << " via list view...";
    for (const auto &e : x->getEdges()) { std::cout << "\nTrying to deactivate edge " << e->getName(); g.deactivateEdge(e); }

    std::cout << "\n\nEdges incident to " << x << ", via map:\n";
    g.mapIncidentEdges(x, [&](const auto &e) { std::cout << e->getName() << ", "; });
    std::cout << "\nEdges incident to " << x << ", via list view:\n";
    for (const auto &e : x->getEdges()) { std::cout << e->getName() << ", "; }

    std::cout << "\nReactivating all edges incident to " << x << " via map...";
    x->mapDeactivatedEdges([&](const auto &e) { std::cout << "\nTrying to reactivate edge " << e->getName(); g.activateEdge(e); });

    std::cout << "\n\nEdges incident to " << x << ", via map:\n";
    g.mapIncidentEdges(x, [&](const auto &e) { std::cout << e->getName() << ", "; });
    std::cout << "\nEdges incident to " << x << ", via list view:\n";
    for (const auto &e : x->getEdges()) { std::cout << e->getName() << ", "; }

    std::cout << "\nDeactivating " << x << "...";
    g.deactivateVertex(x);
    std::cout << "\nReactivating all...";
    g.activateAll();

    std::cout << "\nEdges incident to " << x << ", via map:\n";
    g.mapIncidentEdges(x, [&](const auto &e) { std::cout << e->getName() << ", "; });
    std::cout << "\nEdges incident to " << x << ", via list view:\n";
    for (const auto &e : x->getEdges()) {
        std::cout << e->getName() << " (index: " << x->undirectedIndexOf(e) << "), ";
    }

    std::cout << std::endl;

    return 0;
}
